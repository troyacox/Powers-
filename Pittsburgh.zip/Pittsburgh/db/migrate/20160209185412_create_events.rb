class CreateEvents < ActiveRecord::Migration
  def change
    create_table :events do |t|
      t.text :special
      t.string :day
      t.references :Venue, index: true, foreign_key: true

      t.timestamps null: false
    end
  end
end
