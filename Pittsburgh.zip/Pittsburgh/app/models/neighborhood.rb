class Neighborhood < ActiveRecord::Base
	has_many :venues

end
