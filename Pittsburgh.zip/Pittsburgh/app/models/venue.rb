class Venue < ActiveRecord::Base
  belongs_to :Neighborhood
  has_many :events
  belongs_to :user
end
