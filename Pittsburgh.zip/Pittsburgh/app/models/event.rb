class Event < ActiveRecord::Base
  belongs_to :Venue
end
