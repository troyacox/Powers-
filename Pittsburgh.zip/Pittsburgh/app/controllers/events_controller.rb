class EventsController < ApplicationController
  before_action :set_event, only: [:show, :edit, :update, :destroy]
  before_action :require_admin, only: [:edit, :update, :destroy, :new]
  # GET /events
  # GET /events.json
  def index
    t= Time.now
    if t.wday == 1 
    @events = Event.where( day: "Monday")
    @day_tag = "Monday"
    elsif  t.wday==2
    @events = Event.where(day: "Tuesday")
    @day_tag = "Tuesday"
    elsif  t.wday==3 
    @events = Event.where(day: "Wednesday")
    @day_tag = "Wednesday"
    elsif  t.wday==4
    @events = Event.where(day: "Thursday")
    @day_tag = "Thursday"
    elsif  t.wday==5
    @events = Event.where(day: "Friday")
    @day_tag = "Friday"
    elsif  t.wday==6
    @events = Event.where(day: "Saturday")
    @day_tag = "Saturday"
    elsif  t.wday==7
    @events = Event.where(day: "Sunday")
    @day_tag = "Sunday"
    else
    @events = Event.where(day: "Friday")
    @day_tag = "Friday"
    end
  end
  def shadyside
    @n = "Shadyside"
    t= Time.now
    if t.wday == 1
      x = "Monday"
    elsif  t.wday==2
      x = "Tuesday"
    elsif  t.wday==3
      x = "Wednesday"
    elsif  t.wday==4
      x = "Thursday"
    else
      x = "Friday"
    end
    @v = @venues.where( neighborhood_id: 1)
    @events = Event.where(venue_id: @v.pluck(:id), day: x )
    @events_monday = Event.where(venue_id: @v.pluck(:id), day: "Monday" )
    @events_tuesday = Event.where(venue_id: @v.pluck(:id), day: "Tuesday" )
    @events_wednesday = Event.where(venue_id: @v.pluck(:id), day: "Wednesday" )
    @events_thursday = Event.where(venue_id: @v.pluck(:id), day: "Thursday" )
    @events_friday = Event.where(venue_id: @v.pluck(:id), day: "Friday" )
  end
  

  def oakland
    @n = "Oakland"
    t= Time.now
    if t.wday == 1
      x = "Monday"
    elsif  t.wday==2
      x = "Tuesday"
    elsif  t.wday==3
      x = "Wednesday"
    elsif  t.wday==4
      x = "Thursday"
    else
      x = "Friday"
    end
    @v = @venues.where( neighborhood_id: 3)
    @events = Event.where(venue_id: @v.pluck(:id), day: x )
    @events_monday = Event.where(venue_id: @v.pluck(:id), day: "Monday" )
    @events_tuesday = Event.where(venue_id: @v.pluck(:id), day: "Tuesday" )
    @events_wednesday = Event.where(venue_id: @v.pluck(:id), day: "Wednesday" )
    @events_thursday = Event.where(venue_id: @v.pluck(:id), day: "Thursday" )
    @events_friday = Event.where(venue_id: @v.pluck(:id), day: "Friday" )
  end

  def squirrel_hill
    @n = "Squirrel Hill"
    t= Time.now
    if t.wday == 1
      x = "Monday"
    elsif  t.wday==2
      x = "Tuesday"
    elsif  t.wday==3
      x = "Wednesday"
    elsif  t.wday==4
      x = "Thursday"
    else
      x = "Friday"
    end
    @v = @venues.where( neighborhood_id: 6)
    @events = Event.where(venue_id: @v.pluck(:id), day: x )
    @events_monday = Event.where(venue_id: @v.pluck(:id), day: "Monday" )
    @events_tuesday = Event.where(venue_id: @v.pluck(:id), day: "Tuesday" )
    @events_wednesday = Event.where(venue_id: @v.pluck(:id), day: "Wednesday" )
    @events_thursday = Event.where(venue_id: @v.pluck(:id), day: "Thursday" )
    @events_friday = Event.where(venue_id: @v.pluck(:id), day: "Friday" )
  end
  

  def lawrenceville
    @n = "Lawrenceville"
    t= Time.now
    if t.wday == 1
      x = "Monday"
    elsif  t.wday==2
      x = "Tuesday"
    elsif  t.wday==3
      x = "Wednesday"
    elsif  t.wday==4
      x = "Thursday"
    else
      x = "Friday"
    end
    @v = @venues.where( neighborhood_id: 2)
    @events = Event.where(venue_id: @v.pluck(:id), day: x )
    @events_monday = Event.where(venue_id: @v.pluck(:id), day: "Monday" )
    @events_tuesday = Event.where(venue_id: @v.pluck(:id), day: "Tuesday" )
    @events_wednesday = Event.where(venue_id: @v.pluck(:id), day: "Wednesday" )
    @events_thursday = Event.where(venue_id: @v.pluck(:id), day: "Thursday" )
    @events_friday = Event.where(venue_id: @v.pluck(:id), day: "Friday" )
  end
  

  def southside
    @n = "Southside"
    t= Time.now
    if t.wday == 1
      x = "Monday"
    elsif  t.wday==2
      x = "Tuesday"
    elsif  t.wday==3
      x = "Wednesday"
    elsif  t.wday==4
      x = "Thursday"
    else
      x = "Friday"
    end
    @v = @venues.where( neighborhood_id: 4)
    @events = Event.where(venue_id: @v.pluck(:id), day: x )
    @events_monday = Event.where(venue_id: @v.pluck(:id), day: "Monday" )
    @events_tuesday = Event.where(venue_id: @v.pluck(:id), day: "Tuesday" )
    @events_wednesday = Event.where(venue_id: @v.pluck(:id), day: "Wednesday" )
    @events_thursday = Event.where(venue_id: @v.pluck(:id), day: "Thursday" )
    @events_friday = Event.where(venue_id: @v.pluck(:id), day: "Friday" )
  end
  

  def downtown
    @n = "Downtown"
    t= Time.now
    if t.wday == 1
      x = "Monday"
    elsif  t.wday==2
      x = "Tuesday"
    elsif  t.wday==3
      x = "Wednesday"
    elsif  t.wday==4
      x = "Thursday"
    else
      x = "Friday"
    end
    @v = @venues.where( neighborhood_id: 5)
    @events = Event.where(venue_id: @v.pluck(:id), day: x )
    @events_monday = Event.where(venue_id: @v.pluck(:id), day: "Monday" )
    @events_tuesday = Event.where(venue_id: @v.pluck(:id), day: "Tuesday" )
    @events_wednesday = Event.where(venue_id: @v.pluck(:id), day: "Wednesday" )
    @events_thursday = Event.where(venue_id: @v.pluck(:id), day: "Thursday" )
    @events_friday = Event.where(venue_id: @v.pluck(:id), day: "Friday" )
  end
  
  def mt_washington
    @n = "Mt. Washington"
    t= Time.now
    if t.wday == 1
      x = "Monday"
    elsif  t.wday==2
      x = "Tuesday"
    elsif  t.wday==3
      x = "Wednesday"
    elsif  t.wday==4
      x = "Thursday"
    else
      x = "Friday"
    end
    @v = @venues.where( neighborhood_id: 10)
    @events = Event.where(venue_id: @v.pluck(:id), day: x )
    @events_monday = Event.where(venue_id: @v.pluck(:id), day: "Monday" )
    @events_tuesday = Event.where(venue_id: @v.pluck(:id), day: "Tuesday" )
    @events_wednesday = Event.where(venue_id: @v.pluck(:id), day: "Wednesday" )
    @events_thursday = Event.where(venue_id: @v.pluck(:id), day: "Thursday" )
    @events_friday = Event.where(venue_id: @v.pluck(:id), day: "Friday" )
  end
  
  def friendship
    @n = "Friendship"
    t= Time.now
    if t.wday == 1
      x = "Monday"
    elsif  t.wday==2
      x = "Tuesday"
    elsif  t.wday==3
      x = "Wednesday"
    elsif  t.wday==4
      x = "Thursday"
    else
      x = "Friday"
    end
    @v = @venues.where( neighborhood_id: 7)
    @events = Event.where(venue_id: @v.pluck(:id), day: x )
    @events_monday = Event.where(venue_id: @v.pluck(:id), day: "Monday" )
    @events_tuesday = Event.where(venue_id: @v.pluck(:id), day: "Tuesday" )
    @events_wednesday = Event.where(venue_id: @v.pluck(:id), day: "Wednesday" )
    @events_thursday = Event.where(venue_id: @v.pluck(:id), day: "Thursday" )
    @events_friday = Event.where(venue_id: @v.pluck(:id), day: "Friday" )
  end
  
  def bloomfield
    @n = "Bloomfield"
    t= Time.now
    if t.wday == 1
      x = "Monday"
    elsif  t.wday==2
      x = "Tuesday"
    elsif  t.wday==3
      x = "Wednesday"
    elsif  t.wday==4
      x = "Thursday"
    else
      x = "Friday"
    end
    @v = @venues.where( neighborhood_id: 9)
    @events = Event.where(venue_id: @v.pluck(:id), day: x )
    @events_monday = Event.where(venue_id: @v.pluck(:id), day: "Monday" )
    @events_tuesday = Event.where(venue_id: @v.pluck(:id), day: "Tuesday" )
    @events_wednesday = Event.where(venue_id: @v.pluck(:id), day: "Wednesday" )
    @events_thursday = Event.where(venue_id: @v.pluck(:id), day: "Thursday" )
    @events_friday = Event.where(venue_id: @v.pluck(:id), day: "Friday" )
  end
  
  def north_shore
    @n = "North Shore"
    t= Time.now
    if t.wday == 1
      x = "Monday"
    elsif  t.wday==2
      x = "Tuesday"
    elsif  t.wday==3
      x = "Wednesday"
    elsif  t.wday==4
      x = "Thursday"
    else
      x = "Friday"
    end
    @v = @venues.where( neighborhood_id: 8)
    @events = Event.where(venue_id: @v.pluck(:id), day: x )
    @events_monday = Event.where(venue_id: @v.pluck(:id), day: "Monday" )
    @events_tuesday = Event.where(venue_id: @v.pluck(:id), day: "Tuesday" )
    @events_wednesday = Event.where(venue_id: @v.pluck(:id), day: "Wednesday" )
    @events_thursday = Event.where(venue_id: @v.pluck(:id), day: "Thursday" )
    @events_friday = Event.where(venue_id: @v.pluck(:id), day: "Friday" )
  end
  
  def all
    @events = Event.all
  end

  def monday
    @events = Event.where(day: "Monday")
  end

  def tuesday
    @events = Event.where(day: "Tuesday")
  end

  def wednesday
    @events = Event.where(day: "Wednesday")
  end

  def thursday
    @events = Event.where(day: "Thursday")
  end

  def friday
    @events = Event.where(day: "Friday")
  end

  # GET /events/1
  # GET /events/1.json
  def show
  end

  # GET /events/new
  def new
    @event = Event.new
  end

  # GET /events/1/edit
  def edit
  end

  # POST /events
  # POST /events.json
  def create
    @event = Event.new(event_params)

    respond_to do |format|
      if @event.save
        format.html { redirect_to @event, notice: 'Event was successfully created.' }
        format.json { render :show, status: :created, location: @event }
      else
        format.html { render :new }
        format.json { render json: @event.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /events/1
  # PATCH/PUT /events/1.json
  def update
    respond_to do |format|
      if @event.update(event_params)
        format.html { redirect_to @event, notice: 'Event was successfully updated.' }
        format.json { render :show, status: :ok, location: @event }
      else
        format.html { render :edit }
        format.json { render json: @event.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /events/1
  # DELETE /events/1.json
  def destroy
    @event.destroy
    respond_to do |format|
      format.html { redirect_to events_url, notice: 'Event was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_event
      @event = Event.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def event_params
      params.require(:event).permit(:special, :day, :Venue_id, :start, :end)
    end
end
